#include <iostream>
using namespace std;
int main() {
    int variabile_intera;
    cout <<"inserire una variabile intera: " <<endl;
    cin >>variabile_intera;
    cout <<variabile_intera;
    return 0;
}
