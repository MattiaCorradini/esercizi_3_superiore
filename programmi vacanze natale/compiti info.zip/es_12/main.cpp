#include <iostream>
using namespace std;
int main() {
    int n,m;
    cin >>n >>m;
    if (n>m)
        cout <<n;
    else
        cout <<m;
    return 0;
}

