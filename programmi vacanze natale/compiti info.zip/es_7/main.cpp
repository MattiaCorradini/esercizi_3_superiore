#include <iostream>
using namespace std;
int main() {
    float n;
    cin >>n;
    cout <<n/1000000000;
    return 0;
}
