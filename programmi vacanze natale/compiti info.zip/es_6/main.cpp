#include <iostream>
using namespace std;
int main() {
    int n;
    cin >>n;
    cout <<n*100 <<endl <<n/10 <<endl <<n%3;
    return 0;
}
