#include <iostream>
using namespace std;
int main() {
    int intera;
    float floatt;
    double doublee;
    cin >>intera;
    cin >>floatt;
    cin >>doublee;
    cout <<doublee <<endl;
    cout <<floatt <<endl;
    cout <<intera;
    return 0;
}
