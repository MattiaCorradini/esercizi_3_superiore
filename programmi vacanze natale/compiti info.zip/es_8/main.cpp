#include <iostream>
using namespace std;
int main() {
    double n;
    cin >>n;
    cout <<n/1000000000000;
    return 0;
}
