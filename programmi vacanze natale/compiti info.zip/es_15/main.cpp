#include <iostream>
using namespace std;
int main() {
    float n_1, n_2, n_3;
    cin >>n_1 >>n_2 >>n_3;
    if (n_2-n_1==n_3-n_2)
        cout <<"il primo e il secondo hanno la stessa distanza fra di loro che il secondo e il terzo";
    return 0;
}
