#include <iostream>
using namespace std;
int main() {
    int intero;
    float virgola;
    cin >>intero >>virgola;
    cout <<intero*virgola;
    return 0;
}
