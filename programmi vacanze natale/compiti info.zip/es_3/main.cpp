#include <iostream>
using namespace std;
int main() {
    double variabile_double;
    cout <<"inserire una variabile double: " <<endl;
    cin >>variabile_double;
    cout <<variabile_double;
    return 0;
}
