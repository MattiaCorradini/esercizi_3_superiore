#include <iostream>
using namespace std;
int main() {
    int n;
    cin >>n;
    cout <<n+10 <<endl <<n+100 <<endl <<n+1000;
    return 0;
}
