#include <iostream>
using namespace std;
int main() {
    float variabile_float;
    cout <<"inserire una variabile float: " <<endl;
    cin >>variabile_float;
    cout <<variabile_float;
    return 0;
}
